package com.jpmc.trade.stock.client.model;

public enum StockType {
	COMMON,
	PREFERRED
}
