package com.jpmc.trade.stock.client.model;

public enum StockSymbol {
	TEA,
	POP,
	ALE,
	GIN,
	JOE
}
